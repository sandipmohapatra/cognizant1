package com.cognizant.fsd.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.fsd.spring.model.Book;
import com.cognizant.fsd.spring.repository.BookRepository;

@Service("bookService")
@Transactional
public class BookServiceImpl implements BookService {
	@Autowired
	private BookRepository bookRepository;

	public void setBookRepository(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}

	@Override
	public Book addBook(Book book) {
		return bookRepository.addBook(book);
	}

	@Override
	public boolean deleteBook(long bookId) {
		return bookRepository.deleteBook(bookId);
	}

	@Override
	public Book searchBook(long bookId) {
		return bookRepository.searchBook(bookId);
	}

	@Override
	public List<Book> fetchAllBook() {
		return bookRepository.fetchAllBook();
	}

	@Override
	public List<Book> fetchAllBookBySortingDate() {		
		return bookRepository.fetchAllBookBySortingDate();
	}

	@Override
	public List<Book> fetchAllBookBySortingTitle() {		
		return bookRepository.fetchAllBookBySortingTitle();
	}
}

