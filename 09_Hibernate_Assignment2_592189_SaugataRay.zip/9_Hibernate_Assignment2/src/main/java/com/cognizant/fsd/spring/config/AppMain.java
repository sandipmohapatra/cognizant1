package com.cognizant.fsd.spring.config;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.cognizant.fsd.spring.model.Book;
import com.cognizant.fsd.spring.model.Subject;
import com.cognizant.fsd.spring.service.BookService;
import com.cognizant.fsd.spring.service.SubjectService;

public class AppMain {
	private BookService bookService;
	private SubjectService subjectService;
	 public static void main(String args[]) {
		 new AppMain();
	 }
	 
	 public AppMain() {
	     AbstractApplicationContext context = new AnnotationConfigApplicationContext(RootConfig.class);
		 this.bookService=(BookService) context.getBean("bookService");
		 this.subjectService=(SubjectService) context.getBean("subjectService");
	 
	 
		 while (true) {
				System.out.println("\n");
				System.out.println("enter '1' to add a new subject");
				System.out.println("enter '2' to add a new book");
				System.out.println("enter '3' to delete a subject");
				System.out.println("enter '4' to delete a book");
				System.out.println("enter '5' to search a subject");
				System.out.println("enter '6' to search a book");
				System.out.println("enter '7' to show all");
				System.out.println("enter '8' to exit");
				System.out.println("enter '10' to sort book by title");
				System.out.println("enter '20' to sort subject by title");
				System.out.println("enter '30' to sort book by publish date");

				String input = gatValFromConsole("Enter your choise ");
				select(Integer.parseInt(input));
			}
	 }
	 
	 
		public void select(int i) {
			switch(i) {
			case 1: subjectService.addSubject(addSubject());
			break;
			case 2: bookService.addBook(addBook());
			break;
			case 3: subjectService.deleteSubject(deleteSubject());
			break;
			case 4: bookService.deleteBook(deleteBook());
			break;
			case 5: Subject subject=subjectService.searchSubject(searchSubject());
					System.out.println("Result :"+subject);
			break;
			case 6: Book book=bookService.searchBook(searchBook());
					System.out.println("Result :"+book);
			break;
			case 7: showAll();
			break;
			case 10: bookService.fetchAllBookBySortingTitle().stream().forEach(System.out::println);
			break;
			case 20: subjectService.fetchAllSubjectBySortingTitle().stream().forEach(System.out::println);
			break;
			case 30: bookService.fetchAllBookBySortingDate().stream().forEach(System.out::println);
			break;
			case 8: exit();
			break;
			}	
		}

		
		private void showAll() {		
			System.out.println("\n");
			System.out.println("<------Total Subject List------->");
			subjectService.fetchAllSubject().stream().forEach(System.out::println);
			System.out.println("\n");
			System.out.println("<------Total Book List------->");
			bookService.fetchAllBook().stream().forEach(System.out::println);
		}

		private Subject addSubject() {	
			Subject subject = new Subject();;
			subject.setSubjectId(Long.parseLong(gatValFromConsole("enter subject id")));
			subject.setSubTitle(gatValFromConsole("enter subject title"));
			subject.setDurationInHours(Integer.parseInt(gatValFromConsole("enter duration (In Hours)")));
			System.out.println(subject.toString());
			return subject;
		}
		
		
		private long deleteSubject() {
			long subjectId=Long.parseLong(gatValFromConsole("enter the subject id to be deleted"));
			return subjectId;
		}

		
		private long searchSubject() {
			long subjectId=Long.parseLong(gatValFromConsole("enter the subject id for search"));
			return subjectId;
		}
		
		
		private Book addBook() {	
			Book book = new Book();		
			book.setBookId(Long.parseLong(gatValFromConsole("enter book id")));
			book.setTitle(gatValFromConsole("enter book title"));
			//book.setPrice(Integer.parseInt(gatValFromConsole("enter book price")));
			book.setVolume(Integer.parseInt(gatValFromConsole("enter book volume")));
			book.setPublishDate(LocalDate.parse(gatValFromConsole("enter book publish date(yyyy-mm-dd) ")));
			System.out.println(book.toString());
			return book;
		}
		
		
		private long deleteBook() {
			long bookId=Long.parseLong(gatValFromConsole("enter the book id to be deleted"));
			return bookId;
		}
		
		
		private long searchBook() {
			long bookId=Long.parseLong(gatValFromConsole("enter the book id for search "));
			return bookId;
		}

		
		private String gatValFromConsole(String log) {
			System.out.println(log);
			String inputString = "";
			try {
				BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
				inputString = bufferRead.readLine();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
			return inputString;
		}
		
		
		private void exit() {
			System.exit(0);
		}
}
