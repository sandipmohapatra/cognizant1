package com.cognizant.fsd.spring.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Configuration
@ComponentScan(basePackages = { "com.cognizant.fsd.spring.config","com.cognizant.fsd.spring.controller","com.cognizant.fsd.spring.service","com.cognizant.fsd.spring.repository" })
public class RootConfig {

}
