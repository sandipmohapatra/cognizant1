package com.cognizant;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;

import com.cognizant.model.Book;
import com.cognizant.model.Subject;
import com.cognizant.service.BookService;
import com.cognizant.service.SubjectService;
/**
 * @author Saugata Ray
 *
 */
public class CommandLineRunner {
	private SubjectService subjectService;
	private BookService bookService;

	public void run() {
		while (true) {
			System.out.println("\n");
			System.out.println("enter '1' to add a new subject");
			System.out.println("enter '2' to add a new book");
			System.out.println("enter '3' to delete a subject");
			System.out.println("enter '4' to delete a book");
			System.out.println("enter '5' to search a subject");
			System.out.println("enter '6' to search a book");
			System.out.println("enter '7' to show all");
			System.out.println("enter '8' to exit");
			String input = gatValFromConsole("Enter your choise ");
			select(Integer.parseInt(input));
		}

	}

	public void select(int i) {
		switch (i) {
		case 1:
			addSubject();
			break;
		case 2:
			addBook();
			break;
		case 3:
			deleteSubject();
			break;
		case 4:
			deleteBook();
			break;
		case 5:
			searchSubject();
			break;
		case 6:
			searchBook();
			break;
		case 7:
			showAll();
			break;
		case 8:
			exit();
			break;
		}
	}

	private void addBook() {
		Book book = new Book();
		book.setBookId(Long.parseLong(gatValFromConsole("enter book id")));
		book.setTitle(gatValFromConsole("enter book title"));
		book.setPrice(Double.parseDouble(gatValFromConsole("enter book price")));
		book.setVolume(Integer.parseInt(gatValFromConsole("enter book volume")));
		book.setPublishDate(LocalDate.parse(gatValFromConsole("enter book publish date(yyyy-mm-dd) ")));
		Book bookObj = bookService.addBook(book);
		if (null != bookObj) {
			System.out.println("below mentioned book has been added successfully");
			System.out.println(book.toString());
		} else {
			System.out.println("unable to add book");
		}
	}

	private void deleteBook() {
		long bookId = Long.parseLong(gatValFromConsole("enter the book id to be deleted"));
		if (bookService.deleteBook(bookId))
			System.out.println("book with id :" + bookId + " has been removed");
	}

	private void searchBook() {
		long bookId = Long.parseLong(gatValFromConsole("enter the book id for search"));
		Book book = bookService.searchBook(bookId);
		System.out.println("\n");
		System.out.println("<------Search Result------->");
		System.out.println(book);
	}

	private void addSubject() {
		Subject subject = new Subject();
		subject.setSubjectId(Long.parseLong(gatValFromConsole("enter subject id")));
		subject.setSubTitle(gatValFromConsole("enter subject title"));
		subject.setDurationInHours(Integer.parseInt(gatValFromConsole("enter duration (In Hours)")));

		Subject subjectObj = subjectService.addSubject(subject);
		if (null != subjectObj) {
			System.out.println("below mentioned subject has been added successfully");
			System.out.println(subject.toString());
		} else {
			System.out.println("unable to add subject");
		}
	}

	private void deleteSubject() {
		long subjectId = Long.parseLong(gatValFromConsole("enter the subject id to be deleted"));
		if (subjectService.deleteSubject(subjectId))
			System.out.println("subject with id :" + subjectId + " has been removed");
	}

	private void searchSubject() {
		long subjectId = Long.parseLong(gatValFromConsole("enter the subject id for search"));
		Subject subject = subjectService.searchSubject(subjectId);
		System.out.println("\n");
		System.out.println("<------Search Result------->");
		System.out.println(subject);
	}

	private void showAll() {
		System.out.println("\n");
		System.out.println("<------Total Subject List------->");
		subjectService.fetchAllSubject().stream().forEach(System.out::println);
		System.out.println("\n");
		System.out.println("<------Total Book List------->");
		bookService.fetchAllBook().stream().forEach(System.out::println);
	}

	private void exit() {
		System.exit(0);
	}

	private String gatValFromConsole(String log) {
		System.out.println(log);
		String inputString = "";
		try {
			BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
			inputString = bufferRead.readLine();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return inputString;
	}

	public void setSubjectService(SubjectService subjectService) {
		this.subjectService = subjectService;
	}

	public void setBookService(BookService bookService) {
		this.bookService = bookService;
	}

}
