package com.cognizant.repository;

import java.util.ArrayList;
import java.util.List;

import com.cognizant.model.Subject;

public class SubjectRepositoryImpl implements SubjectRepository{
	private List<Subject> subjectList=new ArrayList<Subject>();
	@Override
	public Subject addSubject(Subject subject) {
		return subjectList.add(subject)?subject:null;
	}

	@Override
	public boolean deleteSubject(long subjectId) {
		return subjectList.removeIf(sub->sub.getSubjectId()==subjectId);
	}

	@Override
	public Subject searchSubject(long subjectId) {
		Subject subject= subjectList.stream()
				.filter(sub -> sub.getSubjectId() == subjectId).reduce((a, b) -> {
				throw new IllegalStateException("Multiple elements: " + a + ", " + b);
			}).get();
			return subject;
	}

	@Override
	public List<Subject> fetchAllSubject() {		
		return subjectList;
	}

}
