package com.cognizant.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cognizant.model.Book;

public class BookRepositoryImpl implements BookRepository{
private List<Book> bookList=new ArrayList<Book>();
	@Override
	public Book addBook(Book book) {		
		return bookList.add(book)?book:null;
	}

	@Override
	public boolean deleteBook(long bookId) {		
		return bookList.removeIf(book->book.getBookId()==bookId);
	}

	@Override
	public Book searchBook(long bookId) {
		Book book= bookList.stream()
				.filter(b -> b.getBookId() == bookId).reduce((a, b) -> {
				throw new IllegalStateException("Multiple elements: " + a + ", " + b);
			}).get();
			return book;
	}

	@Override
	public List<Book> fetchAllBook() {
		return bookList;
	}

}
