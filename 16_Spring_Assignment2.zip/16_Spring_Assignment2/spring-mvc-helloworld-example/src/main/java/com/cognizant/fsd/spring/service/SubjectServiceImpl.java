package com.cognizant.fsd.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.fsd.spring.model.Subject;
import com.cognizant.fsd.spring.repository.SubjectRepository;
@Service("subjectService")
public class SubjectServiceImpl implements SubjectService{
	@Autowired
	private SubjectRepository subjectRepository;

	public void setSubjectRepository(SubjectRepository subjectRepository) {
		this.subjectRepository = subjectRepository;
	}
	@Override
	public Subject addSubject(Subject subject) {
		return subjectRepository.addSubject(subject);
	}
	@Override
	public boolean deleteSubject(long subjectId) {		
		return subjectRepository.deleteSubject(subjectId);
	}
	@Override
	public Subject searchSubject(long subjectId) {	
		return subjectRepository.searchSubject(subjectId);
	}
	@Override
	public List<Subject> fetchAllSubject() {		
		return subjectRepository.fetchAllSubject();
	}

}

