package com.cognizant.fsd.spring.service;

import java.util.List;

import com.cognizant.fsd.spring.model.Book;

public interface BookService {
	public Book addBook(Book book);
	public boolean deleteBook(long bookId);
	public Book searchBook(long bookId);
	public List<Book> fetchAllBook();
}
