package com.cognizant.fsd.spring.repository;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.fsd.spring.datastream.BinarySubjectStreamCRUD;
import com.cognizant.fsd.spring.model.Book;
import com.cognizant.fsd.spring.model.Subject;
@Repository("subjectRepository")
public class SubjectRepositoryImpl implements SubjectRepository{

	private List<Subject> subjectList=new ArrayList<Subject>();
	@Autowired
	private BinarySubjectStreamCRUD binarySubjectStreamCRUD;
	@Override
	public Subject addSubject(Subject subject) {
		subjectList.add(subject);
		saveToBinaryFile(subjectList);
		return subject;
	}

	@Override
	public boolean deleteSubject(long subjectId) {
		boolean flag=subjectList.removeIf(sub->sub.getSubjectId()==subjectId);
		saveToBinaryFile(subjectList);
		return flag;
	}

	
	@Override
	public Subject searchSubject(long subjectId) {
	Subject subject=null;
	try {
		subjectList=binarySubjectStreamCRUD.readRecords();
		System.out.println("subjectList "+subjectList.size());
		subject = subjectList.stream()
				.filter(sub -> sub.getSubjectId() == subjectId).reduce((a, b) -> {
				throw new IllegalStateException("Multiple elements: " + a + ", " + b);
			}).get();
	}catch(Exception exception) {}
			return subject;
	}

	public void saveToBinaryFile(List<Subject> subjectList) {
		try {
			binarySubjectStreamCRUD.open();
			subjectList.forEach(sub->{
				binarySubjectStreamCRUD.writeSubject(sub);
			});	
			binarySubjectStreamCRUD.close();
		} catch (Exception e) {		
			e.printStackTrace();
		}
	}
	

	@Override
	public List<Subject> fetchAllSubject() {		
		return subjectList;
	}
}
