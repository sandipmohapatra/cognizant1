package com.cognizant.fsd.spring.repository;

import java.util.List;

import com.cognizant.fsd.spring.model.Subject;

public interface SubjectRepository {
	public Subject addSubject(Subject subject);
	public boolean deleteSubject(long subjectId);
	public Subject searchSubject(long subjectId);
	public List<Subject> fetchAllSubject();
}
