package com.cognizant.fsd.spring.service;

import java.util.List;

import com.cognizant.fsd.spring.model.Subject;

public interface SubjectService {
	public Subject addSubject(Subject subject);
	public boolean deleteSubject(long subjectId);
	public Subject searchSubject(long subjectId);
	public List<Subject> fetchAllSubject();
}

