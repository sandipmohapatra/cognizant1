package com.cognizant.fsd.spring.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cognizant.fsd.spring.datastream.BinaryBookStreamCRUD;
import com.cognizant.fsd.spring.datastream.BinarySubjectStreamCRUD;

@Configuration
public class RootConfig {
	@Bean
	BinarySubjectStreamCRUD binarySubjectStreamCRUD() {
		return new BinarySubjectStreamCRUD();
	}
	@Bean
	BinaryBookStreamCRUD binaryBookStreamCRUD() {
		return new BinaryBookStreamCRUD();
	}

}
